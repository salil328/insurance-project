# OnlineBankingSystem
Online Baking system. Client side module made on Java Technologies. Database used MySQl.
