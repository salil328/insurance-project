package com.mphasis.mainProject.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	SessionFactory sf=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	
	
	public UserDao(String firstname, String lastname, String username, String email, String password,
			String confirmpass) {
		// TODO Auto-generated constructor stub
	}

	public boolean insertUser(UserDao u) 
	{
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		s.save(u);
		
		t.commit();
		s.close();
		
		return false;
	}
	
	public List<UserDao> getAllUsers()
	{
		Session s=sf.openSession();
		Transaction t1=s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<UserDao> li=s.createQuery("from User").list();
		t1.commit();
		s.close();
		return li;
	}
}
