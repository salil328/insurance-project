package com.mphasis.mainProject.controller;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.mainProject.Dao.UserDao;

@Controller
public class UserController {

	@Autowired
	UserDao ud;
	
	@RequestMapping("/")
	public ModelAndView indexMethod()
	{
		return new ModelAndView("Index");
	}
	
	@RequestMapping("/Register")
	public ModelAndView secondMethod() 
	{
		return new ModelAndView("Register");
	}
	@RequestMapping(value="insertUser", method = RequestMethod.POST)
	public ModelAndView thirdMethod(HttpServletRequest request) 
	{
		
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String username=request.getParameter("username");
		String email=request.getParameter("email");
		String password=request.getParameter("pass");
		String confirmpass=request.getParameter("confirmpass");
		
		UserDao u=new UserDao(firstname,lastname,username,email,password,confirmpass);
		System.out.println(u);
		
		ud.insertUser(u);
		return new ModelAndView("Index");
	}
}
